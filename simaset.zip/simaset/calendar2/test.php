<?php
  echo "No :" . $_POST["no"];
  echo "<br>tgl :" . $_POST["date1"];
?>
