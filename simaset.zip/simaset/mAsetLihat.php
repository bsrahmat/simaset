<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: keluar.php' );
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />

<!-- untuk hint ...................................................... awal-->
<style type="text/css">
#hintbox{ /*CSS for pop up hint box */
position:absolute;
top: 0;
background-color: lightyellow;
width: 150px; /*Default width of hint.*/
padding: 3px;
border:1px solid black;
font:normal 11px Verdana;
line-height:18px;
z-index:100;
border-right: 3px solid black;
border-bottom: 3px solid black;
visibility: hidden;
}

.hintanchor{ /*CSS for link that shows hint onmouseover*/
font-weight: bold;
color: navy;
margin: 3px 8px;
}

</style>

<script type="text/javascript">

/***********************************************
* Show Hint script- � Dynamic Drive (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit http://www.dynamicdrive.com/ for this script and 100s more.
***********************************************/

var horizontal_offset="9px" //horizontal offset of hint box from anchor link

/////No further editting needed

var vertical_offset="0" //horizontal offset of hint box from anchor link. No need to change.
var ie=document.all
var ns6=document.getElementById&&!document.all

function getposOffset(what, offsettype){
var totaloffset=(offsettype=="left")? what.offsetLeft : what.offsetTop;
var parentEl=what.offsetParent;
while (parentEl!=null){
totaloffset=(offsettype=="left")? totaloffset+parentEl.offsetLeft : totaloffset+parentEl.offsetTop;
parentEl=parentEl.offsetParent;
}
return totaloffset;
}

function iecompattest(){
return (document.compatMode && document.compatMode!="BackCompat")? document.documentElement : document.body
}

function clearbrowseredge(obj, whichedge){
var edgeoffset=(whichedge=="rightedge")? parseInt(horizontal_offset)*-1 : parseInt(vertical_offset)*-1
if (whichedge=="rightedge"){
var windowedge=ie && !window.opera? iecompattest().scrollLeft+iecompattest().clientWidth-30 : window.pageXOffset+window.innerWidth-40
dropmenuobj.contentmeasure=dropmenuobj.offsetWidth
if (windowedge-dropmenuobj.x < dropmenuobj.contentmeasure)
edgeoffset=dropmenuobj.contentmeasure+obj.offsetWidth+parseInt(horizontal_offset)
}
else{
var windowedge=ie && !window.opera? iecompattest().scrollTop+iecompattest().clientHeight-15 : window.pageYOffset+window.innerHeight-18
dropmenuobj.contentmeasure=dropmenuobj.offsetHeight
if (windowedge-dropmenuobj.y < dropmenuobj.contentmeasure)
edgeoffset=dropmenuobj.contentmeasure-obj.offsetHeight
}
return edgeoffset
}

function showhint(menucontents, obj, e, tipwidth){
if ((ie||ns6) && document.getElementById("hintbox")){
dropmenuobj=document.getElementById("hintbox")
dropmenuobj.innerHTML=menucontents
dropmenuobj.style.left=dropmenuobj.style.top=-500
if (tipwidth!=""){
dropmenuobj.widthobj=dropmenuobj.style
dropmenuobj.widthobj.width=tipwidth
}
dropmenuobj.x=getposOffset(obj, "left")
dropmenuobj.y=getposOffset(obj, "top")
dropmenuobj.style.left=dropmenuobj.x-clearbrowseredge(obj, "rightedge")+obj.offsetWidth+"px"
dropmenuobj.style.top=dropmenuobj.y-clearbrowseredge(obj, "bottomedge")+"px"
dropmenuobj.style.visibility="visible"
obj.onmouseout=hidetip
}
}

function hidetip(e){
dropmenuobj.style.visibility="hidden"
dropmenuobj.style.left="-500px"
}

function createhintbox(){
var divblock=document.createElement("div")
divblock.setAttribute("id", "hintbox")
document.body.appendChild(divblock)
}

if (window.addEventListener)
window.addEventListener("load", createhintbox, false)
else if (window.attachEvent)
window.attachEvent("onload", createhintbox)
else if (document.getElementById)
window.onload=createhintbox
</script>
<!-- untuk hint ...................................................... end-->


</head>
<body  onload="setFocus()">



<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatasMasuk.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">
						<h1 class="title"><a href="#">Lihat ASET</a></h1>
						<div class="entry">
						        </p>
<!-- tempat main tampilan -->
<div align='right'>
</div>
<font size="3" face="arial" color="blue">Nama Barang<br>
<?php
  //digunakan untuk membedakan antara mAsetLihat dg mAsetLihatKabupaten
  $_SESSION['kodekabupaten'] = "";
  
  include 'bukaDatabase.php';
  $query = "SELECT a.kode,a.nama,a.kodeklasifikasi,b.nama as namaklasifikasi FROM masterbarang a, klasifikasi b where a.kodeklasifikasi=b.kode and a.kode='" . trim(anti_injection($_GET['kodebarang'])) . "'";
  $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
  $rows = pg_num_rows($result);
  if ($rows != 0)
  {
    //tampilkan nama barang
    while ($row = pg_fetch_row($result))
    {
       echo "<input readonly type='text' size='60' maxlength='100' value='$row[1]' STYLE='color: white; font-family: Verdana; font-weight: bold; font-size: 14px; background-color: green;'>";
       echo "<br><br>Kategori<br><input readonly type='text' size='50' maxlength='50' value='$row[3]' STYLE='color: white; font-family: Verdana; font-weight: bold; font-size: 14px; background-color: green;'>";
    }
    
    //lihat di aset / transaksi aset
    //                    0           1    2      3         4       5         6             7          8         9
    $query = "SELECT a.kodebarang,a.id2,a.jumlah,a.harga,a.status,a.tanggal,a.idpengadaan,a.mutasi,b.nama,a.kodekabupaten from  aset a, kabupaten b where a.kodekabupaten=b.kode and a.kodebarang='" . $_GET['kodebarang'] . "' order by a.tanggal desc";
    //echo $query;
    $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
    echo "<br><br>Transaksi Aset<br><table bgcolor='#DFFFDF' width='100%' border='1'>";
    echo "<tr bgcolor='#88FF88' ><td>No</td><td>Jumlah</td><td>Harga</td><td>Status</td><td>TglPerolehan</td><td>Detail</td></tr>";
    $no=0;
    $jmlAset=0;
    while ($row = pg_fetch_row($result))
    {
       $no=$no+1;
       ?><tr  onMouseOut="this.bgColor='#EAFFEA';" bgcolor='#EAFFEA' onMouseover="this.bgColor='#FFFF80';" ><?php

       echo "<td>$no";
       $vKab=$row[8];
       ?>
       <a href="mAsetLihatKabupaten.php?kodekabupaten=<?php echo trim($row[9]); ?>&kodebarang=<?php echo trim(anti_injection($_GET['kodebarang'])); ?>" class="hintanchor" onMouseover="showhint('<?php echo trim($vKab); ?>' , this, event, '150px')"><img src='images/view.jpg'></a>
       <?php
       echo "</td><td>$row[2]</td><td>" . number_format ( $row[3] , 2 , ',' , '.' ) . "</td><td>$row[4]</td><td>$row[5]</td><td>";
                               //cek dr pengadaan
                               if (is_null($row[6]))
                               {
                                         if ($row[7]<>"M")
                                         {
                                             echo "<a href='mAsetDetail.php?kode=$row[1]'  ><img src='images/update.jpg'></a>";
                                         }
                                         echo "<a href='mAsetDetail.php?kode=$row[1]' > <img src='images/x.gif'></a>";
                               } else
                               {
                                  echo "pengadaan";
                                  echo "<a href='mAsetDetail.php?kode=$row[1]' > <img src='images/x.gif'></a>";
                               }
                               
                                         if ($row[7]<>"M")
                                         {
                                         ?>
                                         <a href="mAsetMutasi.php?kode=<?php echo $row[1];?>" class="hintanchor" onMouseover="showhint('Mutasi Aset', this, event, '50px')"><img src='images/mutasi.gif'></a>
                                         <?php
                                         } else
                                         {
                                            echo " Mutasi";
                                         }
       if (trim(strtoupper($row[4]))=="BERTAMBAH")
       {
          $jmlAset=$jmlAset+$row[2];
       }
       else
       {
          $jmlAset=$jmlAset-$row[2];
       }

       echo "</td></tr>";
    }
    echo "</table>";
    echo "<img src='images/view.jpg'>:Info Kabupaten <img src='images/mutasi.gif'>:Mutasi<br>";
    echo "Jumlah ASET : $jmlAset";
    echo "<div align='right'><a href='mAsetTambah.php?kodebarang=" . trim(anti_injection($_GET['kodebarang'])) . "'><img width='30' src='images/tambah.jpg'></a></div>";
  }
?>
</font>
<br><br><br><br><br><br>

							</p>
						</div>
					</div>

					<div class="post">
					  <h1 class="title"><a href="#"><?php echo "User : (" . $_SESSION["userid"] . ")" . $_SESSION["nama"]; ?></a></h1>
					</div>

				</div>
				<!-- end #content -->
				<?php
                                include 'menuMasuk.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
