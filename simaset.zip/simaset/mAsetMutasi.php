<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: keluar.php' );
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />


<script type="text/javascript">
<!-- Begin ....................... script untuk rupiah .....................
function formatCurrency(num) {
num = num.toString().replace(/\Rp. |\,/g,'');
if(isNaN(num))
num = "0";
sign = (num == (num = Math.abs(num)));
num = Math.floor(num*100+0.50000000001);
cents = num%100;
num = Math.floor(num/100).toString();
if(cents<10)
cents = "0" + cents;
for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
num = num.substring(0,num.length-(4*i+3))+','+
num.substring(num.length-(4*i+3));
return (((sign)?'':'-') + 'Rp. ' + num + '.' + cents);
}
//  End -->
</script>


<script type="text/javascript">
<!-- Begin ....................... script untuk rupiah .....................
function awalformatCurrency() {
var nn = document.input1.hargasatuan.value;
document.input1.hargaasli.value = nn;
document.input1.hargasatuan.value = formatCurrency(document.input1.hargasatuan.value);
}
//  End -->
</script>



</head>
<body  onload="awalformatCurrency()">



<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatasMasuk.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">
						<h1 class="title"><a href="#">Mutasi ASET</a></h1>
						<div class="entry">
						        </p>
<!-- tempat main tampilan -->
<form action="mAsetMutasiSimpan.php" method="post" name="input1">
<font size="3" face="arial" color="blue">Nama Aset<br><select readonly name="kodebarang" STYLE="color: white; background-color: #FF6600;text-align: left">
<?php
  include 'bukaDatabase.php';
  //Postgres = pg_escape_string()
  // generate and execute a query
  $query = "SELECT *,to_char(harga,'999999999999999D9') as har FROM aset where id2='" . trim(anti_injection($_GET['kode'])) . "'";

  $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
  $kodebarang="";
  $jumlah=0;
  $harga=0;
  $kodekabupaten="";
  $date1="";
  $userid="";
  $status="";
  while ($row = pg_fetch_row($result))
  {
     $kodebarang=$row[0];
     $jumlah=$row[1];
     $harga=$row[14];
     $kodekabupaten=$row[8];
     $date1=$row[4];
     $keterangan=$row[7];
     $userid="UserId : " . trim($row[5]) ." , TanggalEntry $row[6]";
     $status=$row[3];
  }

  $query = "SELECT * FROM masterbarang where kode='$kodebarang'";

  $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
  // get the number of rows in the resultset
  $rows = pg_num_rows($result);
  if ($rows != 0)
  {
    //echo "<table width='100%' border='1'>";
    while ($row = pg_fetch_row($result))
    {
      echo "<option value='" . $row[0] ."'>" . $row[1] . "</option>";
    }
  }
?>
</select><br>
<table>
<tr><td>
Jumlah<br><input readonly type="text" size='5' maxlength='3' name="j1umlah"  value="<?php echo $jumlah; ?>" STYLE="color: white; background-color: #FF6600;text-align: right">
</td></tr>
<tr>
<td>
Harga Satuan<br><input readonly type="text" name="hargasatuan"  STYLE="color: white; background-color: #FF6600;text-align: right" value="<?php echo $harga; ?>" onBlur="this.value=formatCurrency(this.value);" >
<input type="hidden" name="parentid" value="<?php echo trim(anti_injection($_GET['kode'])); ?>">
<input type="hidden" name="hargaasli">
</td>
</tr>
</table>

<br>Kabupaten<br><select name="asalkodekabupaten" STYLE="color: white; background-color: #FF6600;">
<?php
  //Postgres = pg_escape_string()
  // generate and execute a query
  $query = "SELECT * FROM kabupaten where kode='$kodekabupaten'";

  $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
  // get the number of rows in the resultset
  $rows = pg_num_rows($result);
  if ($rows != 0)
  {
    //echo "<table width='100%' border='1'>";
    while ($row = pg_fetch_row($result))
    {
        echo "<option value='" . $row[0] ."'>" . $row[1] . "</option>";
    }
  }

?>
</select><br><br>

<table border='0'>
<tr><td valign='top'>
Tanggal Perolehan<br><input type="text" readonly name="dateasli" STYLE="color: white; background-color: #FF6600;" value="<?php echo $date1; ?>"/>
</td>
</tr>
<tr><td>

</td></tr>
</table>

<br>Mutasi Ke Kabupaten<br><select name="kodekabupaten">
<?php
  //Postgres = pg_escape_string()
  // generate and execute a query
  $query = "SELECT * FROM kabupaten order by kode";

  $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
  // get the number of rows in the resultset
  $rows = pg_num_rows($result);
  if ($rows != 0)
  {
    //echo "<table width='100%' border='1'>";
    while ($row = pg_fetch_row($result))
    {
        echo "<option value='" . $row[0] ."'>" . $row[1] . "</option>";
    }
  }

?>
</select><br><br>

Jumlah<br><input  type="text" size='5' maxlength='3' name="jumlah"   STYLE="text-align: right"><br><br>

Keterangan<br><input size='20' maxlength='20' type="text" name="keterangan" value="<?php echo $keterangan?>"><br><br>

<input type="submit" value=" Simpan Mutasi " STYLE="color: white; font-family: Verdana; font-weight: bold; font-size: 18px; background-color: green;">
</form>
</font>
<br><br><br><br><br><br>

							</p>
						</div>
					</div>

					<div class="post">
					  <h1 class="title"><a href="#"><?php echo "User : (" . $_SESSION["userid"] . ")" . $_SESSION["nama"]; ?></a></h1>
					</div>

				</div>
				<!-- end #content -->
				<?php
                                include 'menuMasuk.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
