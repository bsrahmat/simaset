<div id="menu">
	<ul>
		<li><a href="index.html">Beranda</a></li>
		<li><a href="#">Manual</a></li>
		<li><a href="login.php">Login</a></li>
		<li><a href="#">Link</a></li>
	</ul>
</div>

