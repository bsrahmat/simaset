<?php
  if ($_SESSION['userid']=="")
  {
     exit();
  }
?>
				<div id="sidebar">
					<ul>
						<li>
							<h2>Pengadaan</h2>
							<ul>
								<li><a href="mPengadaan.php">Input Pengadaan</a><span>untuk input data pengadaan barang</span></li>
								<li><a href="mPengadaanList.php">Edit Pengadaan</a><span>Menu untuk edit data pengadaan barang</span></li>
								<li><a href="mPengadaanList.php">Hapus Pengadaan</a><span>Menghapus jika pengadaan batal dilakukan</span> </li>
								<li><a href="mPengadaanList.php">Acc Pengadaan</a><span>Acc pengadaan barang (Masuk ke ASET)</span> </li>
								<li><a href="mPengadaanSearch.php">Cari Pengadaan</a><span>Mencari pengadaan barang</span> </li>
								<li><a href="mPengadaanLaporan.php">Laporan Realisasi</a><span>Cetak Laporan Realisasi</span> </li>
							</ul>
						</li>
						<li>
							<h2>Aset</h2>
							<ul>
								<li><a href="mAset.php">Input</a><span>Entry Aset Masuk Non Pengadaan</span> </li>
								<li><a href="mAsetSearch.php">Edit</a><span>Edit Aset</span> </li>
								<li><a href="mAsetSearch.php">Hapus</a><span>Hapus Aset</span> </li>
								<li><a href="mAsetSearch.php">Mutasi</a><span>Mutasi Aset</span> </li>
								<li><a href="mAsetLaporanMutasiKabupaten1.php">Laporan Mutasi Aset berdasar Kabupaten</a><span>Laporan Mutasi Aset berdasar Kabupaten</span> </li>
								<li><a href="mAsetLaporanMutasiJenis1.php">Laporan Mutasi Aset berdasar Jenis Barang</a><span>Laporan Mutasi Aset berdasar Jenis Barang</span> </li>
								<li><a href="mAsetKartu.php">Kartu Pengawas Aset</a><span>Kartu Pengawas Aset </span> </li>
							</ul>
							<h2>Lain-lain</h2>
							<ul>
								<li><a href="mKabupaten.php">Daftar Kabupaten</a><span>Daftar kabupaten yang ada di papua</span> </li>
								<li><a href="mKlasifikasi.php">Klasifikasi Barang</a><span>Daftar Klasifikasi Aset Barang</span> </li>
								<li><a href="mBarang.php">Daftar Barang</a><span>Daftar Aset barang </span> </li>
								<li><a href="mKomponen.php">Komponen Barang</a><span>Daftar Komponen Barang </span> </li>
								<li><a href="mRekanan.php">Daftar Rekanan</a><span>Daftar Rekanan</span> </li>
								<li><a href="gantiPassword.php">Ganti Password</a><span>Menganti Password</span> </li>
								<li><a href="keluar.php">Keluar</a><span>Keluar dari sistem</span> </li>
							</ul>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->

