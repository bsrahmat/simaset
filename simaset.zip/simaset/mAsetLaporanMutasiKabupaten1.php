<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: keluar.php' );
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />



</head>
<body >



<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatasMasuk.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">
						<h1 class="title"><a href="#">Rekapitulasi Daftar Mutasi Barang Inventaris Per Kabupaten</a></h1>
						<div class="entry">
						        </p>
<!-- tempat main tampilan -->

<form action="mAsetLaporanMutasiKabupaten2.php" method="get" name="input1">
<font size="3" face="arial" color="blue">
<!-- .......................................................... untuk memasukan  tanggal
Tanggal<br><input type="text" id="date1"  name="date1"/>
<script type="text/javascript">
    var ng_config = {
        assests_dir: 'assets/'	// the path to the assets directory
    }
</script>
<script type="text/javascript" src="ng_all.js"></script>
<script type="text/javascript" src="components/calendar.js"></script>
<script type="text/javascript">
var my_cal;
ng.ready(function(){
        // creating the calendar
        my_cal = new ng.Calendar({
            num_months:6,
            num_col:3,
            multi_selection:true,
            max_selection:2,
            input: 'date1',            // the input field id
            start_date: 'year - 5',    // the start date (default is today)
            display_date: new Date()   // the display date (default is start_date)
        });
    });
</script>
-->

Semester<br>
<select type='text' name='semester'>
 <option value="1">Semester 1</option>
 <option value="2">Semester 2</option>
</select>
<br><br>
Tahun<br>
<input type='text' name='tahun' size='4' value='<?php echo date("Y"); ?>' maxlength='4'>
<br><br>

Record Satu Page<br>
<input type='text' name='Recordpage' value='6' size='3' maxlength='3'>
<br><br>
<input type='hidden' name='page' value='1'>
<input type='submit' name='masuk' value=' Proses Laporan ' STYLE="color: white; font-family: Verdana; font-weight: bold; font-size: 21px; background-color: green;">
</form>

</font>
<br><br>
<br><br><br><br><br><br>

							</p>
						</div>
					</div>

					<div class="post">
					  <h1 class="title"><a href="#"><?php echo "User : (" . $_SESSION["userid"] . ")" . $_SESSION["nama"]; ?></a></h1>
					</div>

				</div>
				<!-- end #content -->
				<?php
                                include 'menuMasuk.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
