				<div id="sidebar">
					<ul>
						<li>
							<h2></h2>
							<ul>
								<li><a href="index.html">Beranda</a><span>halaman depan sistem informasi manajemen aset</span></li>
								<li><a href="login.php">Login</a><span>untuk masuk ke sistem manajemen aset</span></li>
								<li><a href="#">Link</a><span>daftar Link</span></li>
								
							</ul>
						</li>
					</ul>
	<img src='images/qrcode.jpg'>
				</div>

