<?php
function anti_injection($sql)
 {

          // daftarkan perintah-perintah SQL yang tidak boleh ada
          // dalam query dimana SQL Injection mungkin dilakukan

          $aforbidden = array ("insert", "select", "update", "delete", "truncate","replace", "drop", " or ", ";", "#", "--", "=" );
          // lakukan cek, input tidak mengandung perintah yang tidak boleh
          $breturn=true;
          foreach($aforbidden as $cforbidden)
          {
              if(strripos($sql, $cforbidden)===0)
              {
                  $breturn=false;
                  break;
              }
          }

   if ($breturn==true)
   {
   $sql = pg_escape_string(stripslashes(strip_tags(htmlspecialchars($sql,ENT_QUOTES))));
   $sql = trim($sql); // strip whitespace
   $sql = strip_tags($sql); // strip HTML and PHP tags
   $sql = addslashes($sql); // quote string with slashes
   $sql = htmlspecialchars($sql);
   $sql = str_replace("'", '& #039;', $sql);
   $sql = str_replace('"', '&quote;', $sql);
   return $sql;
   } else
   {
     $sql="";
     return $sql;
   }
}
?>
