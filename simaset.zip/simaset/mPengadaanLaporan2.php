<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: keluar.php' );
  }
?>
<body >
<?php
// untuk paging awal.....................................................
define("IN_PAGI", true);
$home="mPengadaanLaporan.php";
require("class_pagination.php");
$page = intval($_GET['page']);
if(empty($page))
{$page = 1;}
// untuk paging awal.....................................................
?>


<!-- tempat main tampilan -->
<?php
  //echo $_POST['date1'] . "<br><br><br>";
  $hasil = preg_split('/,/', $_GET['date1']); // hasil
  $kodekomponen=$_GET['kodekomponen'];
  $Recordpage=$_GET['Recordpage'];
  //echo "Awal : " . $hasil[0] . "<br><br><br>";
  //echo "Akhir : " . $hasil[1] . "<br><br><br>";
  //print_r($hasil);
?>
				<?php
		                    include 'bukaDatabase.php';
		                    //                 0     1        2        3        4       5         6                7          8
                                    $query = "select a.id2,a.no,a.kodebarang,b.nama,a.jumlah,a.harga,a.nopemeriksaan,a.koderekanan,a.keterangan from pengadaan a, masterbarang b ";
                                    $query = $query . " where a.tanggal between '" . $hasil[0] . "' and '" . $hasil[1] . "' and a.kodebarang=b.kode and b.kodekomponen='$kodekomponen' order by tanggal";

                                    $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
                                    $rows = pg_num_rows($result);
                                    $generated=$rows;
                                    
                                    //untuk paging
                                    //http://localhost/papua/mPengadaanLaporan2.php?date1=2011-10-1%2C2011-12-31&kodekomponen=0001&page=1&masuk=+Proses+Laporan+
		                    $pagination = new Pagination($Recordpage, $generated, $page, "mPengadaanLaporan2.php?Recordpage=" . $Recordpage . "&date1=" . $_GET['date1'] . "&kodekomponen=" . $kodekomponen . "&page");
                      		    $start = $pagination->prePagination();

                                    if ($rows != 0)
                                    {
                                       echo "<div align='center'><h2><u>LAPORAN REALISASI PENGADAAN BARANG / JASA</u></h2></div>";
                                       echo "<table>";
                                       echo "<tr><td>NAMA INSTANSI</td><td>: BADAN PENGELOLAAN INFRASTRUKTUR PROVINSI PAPUA</td></tr>";
                                         //Komponen
                                         $query1 = "select * from komponen where kode='" . $kodekomponen . "'";
                                         $result1 = pg_query($connection, $query1) or die("Error in query: $query1. " . pg_last_error($connection));
                                         $rows1 = pg_num_rows($result1);
                                         while ($row1 = pg_fetch_row($result1))
                                         {
                                            echo "<tr><td>KOMPONEN BARANG*)</td><td>: " . trim($row1[1]) . " </td></tr>";
                                         }


                                       echo "</table>";
                                       echo "<table width='100%' border='1'>";
                                       echo "<tr bgcolor='#80FF80' align='center'><td>No</td><td>No/Tgl.Kontrak</td><td>Nama</td><td>Jumlah</td><td>Harga Satuan</td><td>Jumlah Harga</td><td>No/Tgl.BA<br>Pemeriksaan Barang</td><td>Nama<br>Rekanan</td><td>Ket</td></tr>";
                                       $vNo=0;
                                       
                                       //untuk paging
                                       $query = "select a.id2,a.no,a.kodebarang,b.nama,a.jumlah,a.harga,a.nopemeriksaan,a.koderekanan,a.keterangan,b.satuan from pengadaan a, masterbarang b ";
                                       $query = $query . " where a.tanggal between '" . $hasil[0] . "' and '" . $hasil[1] . "' and a.kodebarang=b.kode and b.kodekomponen='$kodekomponen' ";
                                       $query = $query . " order by a.tanggal LIMIT $Recordpage OFFSET $start ";
                                       //echo $query;
                                       $query2  = pg_query($query);
                                       
                                       while($row = pg_fetch_assoc($query2))
                                       //while ($row = pg_fetch_row($query))
                                       {
                                         $vNo = $vNo + 1;
                                         ?><tr onMouseOver="this.bgColor='#FFFF80'" onMouseOut="this.bgColor='#EAFFEA'" bgcolor='#EAFFEA'><?php
                                         echo "<td>$vNo</td>";
                                         echo "<td>" . stripslashes(htmlspecialchars($row['no'])) . "</td>";
                                         echo "<td>" . stripslashes(htmlspecialchars($row['nama'])) . "</td>";
                                         echo "<td align='center'>" . stripslashes(htmlspecialchars($row['jumlah'])) . " " . trim(stripslashes(htmlspecialchars($row['satuan']))) . "</td>";
                                         echo "<td align='right'>Rp." . number_format ( $row['harga'] , 2 , ',' , '.' ) . "</td>";
                                         echo "<td align='right'>Rp." . number_format ( $row['jumlah']*$row['harga'] , 2 , ',' , '.' ) . "</td>";
                                         //rekanan
                                         $query1 = "select * from rekanan where kode='" . $row['koderekanan'] . "'";
                                         $result1 = pg_query($connection, $query1) or die("Error in query: $query1. " . pg_last_error($connection));
                                         $rows1 = pg_num_rows($result1);
                                         while ($row1 = pg_fetch_row($result1))
                                         {
                                            echo "<td>" . trim($row1[1]) . "</td>";
                                         }


                                         echo "<td>". stripslashes(htmlspecialchars($row['keterangan'])) . "</td>";
                                       }
                                       echo "</table>";
		                       $pagination->pagination();
		                       //echo "<a href='mPengadaanLaporan.php'>home</a>";
                                    }
                                     ?>
                                     *) Catatan : Diisi menurut komponen barang<br>
                                     - Inventaris<br>
                                     - ATK<br>
                                     - Cetakan<br>
                                     - Pakaian Dinas<br>
                                     - Dll
                                     <table width='100%' border='0'>
                                        <tr><td>
                                        <?php
                                        for ( $counter = 0; $counter <= 90; $counter += 1)
                                        {
                                          echo "&nbsp";
                                        }
                                        ?>
                                        </td>
                                        <td align='center'>
                                        KEPALA<br>
                                        BADAN PENGELOLAAN INFRASTRUKTUR<br>
                                        PROVINSI PAPUA<br>
                                        <br><br><br>
                                        Ir.J.I.CHRISTIANWAYOI,MMT,MT<br>
                                        Pembina Utama Muda<br>
                                        NIP.19590101 199103 1 013

                                        </td></tr>
                                     </table>

</html>
