<?php
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript">

var formInUse = false;

function setFocus()
{
 if(!formInUse) {
  document.input1.userid1.focus();
 }
}

</script>
</head>
<body  onload="setFocus()">
<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatas.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">
						<h1 class="title"><a href="#">Login</a></h1>
						<font size="3" face="arial" color="black">
						<FORM action="masuk.php" method="post" name="input1">
						<div class="entry">
                                                        <p>
                                                        <table>
                                                        <tr>
                                                          <td valign='top' rowspan='4'>
							    <img src='images/login.jpg'>
							  </td>
                                                          <td>
                                                            UserId<br>
							    <input name='userid1' size='10' STYLE="color: black; font-family: Verdana; font-weight: bold; font-size: 18px; background-color: #EAFFF4;">
							  </td>
							</tr>
							<tr>
							  <td>
                                                            Password<br>
							    <input type='password' name='pass' size='10' STYLE="color: black; font-family: Verdana; font-weight: bold; font-size: 16px; background-color: #EAFFF4;">
							  </td>
							</tr>
							<tr>
							  <td>
							    <img width='100' src="php_captcha.php"><br>
							    <input name="number" type="text" id=\&quot;number\&quot; STYLE="color: black; font-family: Verdana; font-weight: bold; background-color: #EAFFF4;">
							  </td>
							</tr>
							<tr>
							  <td>
							    <input type='submit' name='masuk' value='Masuk' STYLE="color: white; font-family: Verdana; font-weight: bold; font-size: 18px; background-color: green;">
							  </td>
							</tr>
							</table>
							</p>
                                                 </form>
						</div>
					</div>
				</div>
				<!-- end #content -->
				<?php
                                include 'menu.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
