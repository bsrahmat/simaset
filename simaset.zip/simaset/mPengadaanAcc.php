<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: keluar.php' );
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />

<script type="text/javascript">
<!-- Begin ....................... script untuk rupiah .....................
function formatCurrency(num) {
num = num.toString().replace(/\Rp. |\,/g,'');
if(isNaN(num))
num = "0";
sign = (num == (num = Math.abs(num)));
num = Math.floor(num*100+0.50000000001);
cents = num%100;
num = Math.floor(num/100).toString();
if(cents<10)
cents = "0" + cents;
for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
num = num.substring(0,num.length-(4*i+3))+','+
num.substring(num.length-(4*i+3));
return (((sign)?'':'-') + 'Rp. ' + num + '.' + cents);
}
//  End -->
</script>

<script type="text/javascript">
<!-- Begin ....................... script untuk rupiah .....................
function awalformatCurrency() {
var nn = document.input1.hargasatuan.value;
document.input1.hargaasli.value = nn;
document.input1.hargasatuan.value = formatCurrency(document.input1.hargasatuan.value);
}
//  End -->
</script>
</head>



<body  onload="awalformatCurrency()">
<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatasMasuk.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">
						<h1 class="title"><a href="#">ACC Pengadaan</a></h1>
						<div class="entry">
						        </p>
<!-- tempat main tampilan -->
<?php
  $id2=anti_injection($_GET["id2"]);
  include 'bukaDatabase.php';
  $query = "SELECT *,to_char(harga,'999999999999999D9') as har FROM pengadaan where id2=$id2";
  $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
  $rows = pg_num_rows($result);
  if ($rows != 0)
  {
    while ($row = pg_fetch_row($result))
    {
      $no=$row[0];
      $kodebarang=$row[1];
      $jumlah=$row[2];
      $hargasatuan=$row[11];
      $pemeriksaan=$row[4];
      $koderekanan=$row[8];
      $keterangan=$row[5];
      $date1=$row[6];
      $userid=$row[7];
      $tanggalentry=$row[10];
    }
  } else
  {
    echo "data tidak ada";
    exit();
  }
?>


<form action="mPengadaanAccSimpan.php" method="post" name="input1">
<font size="3" face="arial" color="blue">Nama Aset<br><select readonly name="kodebarang" STYLE="color: white; background-color: #FF6600;text-align: left">
<?php
  //$kodebarang=trim(anti_injection($_GET['kodebarang']));

  $query = "SELECT * FROM masterbarang where kode='$kodebarang'";

  $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
  $rows = pg_num_rows($result);
  if ($rows != 0)
  {
    while ($row = pg_fetch_row($result))
    {
      echo "<option value='" . $row[0] ."'>" . $row[1] . "</option>";
    }
  }
?>
</select><br><br>
<table>
<tr><td>
Jumlah<br><input type="text" size='5' maxlength='3' name="jumlah" value="<?php echo $jumlah; ?>" STYLE="color: white; text-align: right; background-color: #FF6600;">
</td></tr>
<tr>
<td>
Harga Satuan<br><input type="text" name="hargasatuan" readonly value="<?php echo $hargasatuan; ?>" STYLE="color: white; text-align: right; background-color: #FF6600;"onBlur="this.value=formatCurrency(this.value);" >
<input type="hidden" name="hargaasli">
<input type="hidden" name="idpengadaan" value="<?php echo $id2;?>">
</td>
</tr>
</table>
<table border='0'>
<tr>
<td valign='top'>
<!-- .......................................................... untuk memasukan  tanggal -->
Tanggal Perolehan <br><input type="text" id="date1" name="date1" value="<?php echo $date1; ?>" STYLE="color: white; text-align: left; background-color: #FF6600;" />
</td></tr>
</table>

<br>Aset Kabupaten<br><select name="kodekabupaten">
<?php
  //Postgres = pg_escape_string()
  // generate and execute a query
  $query = "SELECT * FROM kabupaten order by kode";

  $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
  // get the number of rows in the resultset
  $rows = pg_num_rows($result);
  if ($rows != 0)
  {
    //echo "<table width='100%' border='1'>";
    while ($row = pg_fetch_row($result))
    {
        echo "<option value='" . $row[0] ."'>" . $row[1] . "</option>";
    }
  }

?>
</select><br><br>

<input type="submit" value=" Simpan " STYLE="color: white; font-family: Verdana; font-weight: bold; font-size: 18px; background-color: green;">
</form>
</font>
<br><br><br><br><br><br>

							</p>
						</div>
					</div>

					<div class="post">
					  <h1 class="title"><a href="#"><?php echo "User : (" . $_SESSION["userid"] . ")" . $_SESSION["nama"]; ?></a></h1>
					</div>

				</div>
				<!-- end #content -->
				<?php
                                include 'menuMasuk.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
