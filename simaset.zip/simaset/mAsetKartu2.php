<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: keluar.php' );
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />

<!-- untuk hint ...................................................... awal-->
<style type="text/css">
#hintbox{ /*CSS for pop up hint box */
position:absolute;
top: 0;
background-color: lightyellow;
width: 150px; /*Default width of hint.*/
padding: 3px;
border:1px solid black;
font:normal 11px Verdana;
line-height:18px;
z-index:100;
border-right: 3px solid black;
border-bottom: 3px solid black;
visibility: hidden;
}

.hintanchor{ /*CSS for link that shows hint onmouseover*/
font-weight: bold;
color: navy;
margin: 3px 8px;
}

</style>


<script type="text/javascript" src="chart/jscharts.js"></script>

</head>
<body  onload="setFocus()">



<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatasMasuk.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">
						<h1 class="title"><a href="#">Kartu ASET</a></h1>
						<div class="entry">
						        </p>
<!-- tempat main tampilan -->
<div align='right'>
</div>
<?php
// untuk paging awal.....................................................
define("IN_PAGI", true);
$home="mAsetKartu.php";
require("class_pagination.php");
$page = intval($_GET['page']);
if(empty($page))
{$page = 1;}
// untuk paging awal.....................................................
?>



<font size="4" face="arial" color="blue">Kabupaten<br>
<?php
  $Recordpage=$_GET['Recordpage'];
  $kodekabupaten=$_GET['kodekabupaten'];

  include 'bukaDatabase.php';
  
  $query = "SELECT * ";
  $query = $query . " FROM kabupaten where kode='$kodekabupaten'";
  $query2  = pg_query($query);
  while($row = pg_fetch_assoc($query2))
  {
  ?>
    <input readonly size='50' type='text' value='<?php echo $row['nama']; ?>'STYLE="color: black; font-family: Verdana; font-weight: bold; font-size: 16px; background-color: #EAFFF4;">
  <?php
  }
  echo "<br><br>Nama Barang<br>";

  
  $query = "SELECT a.kodebarang,b.nama,count(*) as jml ";
  $query = $query . " FROM aset a, masterbarang b where a.kodebarang=b.kode and a.kodekabupaten='$kodekabupaten'";
  $query = $query . " group by a.kodebarang,b.nama ";

                                    $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
                                    $rows = pg_num_rows($result);
                                    $generated=$rows;
		                    $pagination = new Pagination($Recordpage, $generated, $page, "mAsetKartu2.php?Recordpage=" . $Recordpage . "&kodekabupaten=" . $kodekabupaten . "&page");
                      		    $start = $pagination->prePagination();
                                    if ($rows != 0)
                                    {
                                       $query = "SELECT a.kodebarang,b.nama,count(*) as jml ";
                                       $query = $query . " FROM aset a, masterbarang b where a.kodebarang=b.kode and a.kodekabupaten='$kodekabupaten'";
                                       $query = $query . " group by a.kodebarang,b.nama ";
                                       $query = $query . " order by a.kodebarang,b.nama LIMIT $Recordpage OFFSET $start ";
                                       $query2  = pg_query($query);
                                       
                                       while($row = pg_fetch_assoc($query2))
                                       {
                                         $namaBarang=trim($row['nama']);
                                         //Cari Jumlah Keluar dan Masuk Barang
                                         $query1 = "select status,sum(jumlah) as jml from aset where kodebarang='" . $row['kodebarang'] . "' and kodekabupaten='$kodekabupaten' group by status";
                                         $result1 = pg_query($connection, $query1) or die("Error in query: $query1. " . pg_last_error($connection));
                                         $rows1 = pg_num_rows($result1);
                                         $Masuk=0;$Keluar=0;$Total=0;
                                         while ($row1 = pg_fetch_row($result1))
                                         {
                                            if (trim(strtoupper($row1[0]))=="BERTAMBAH")
                                            {$Masuk=$Masuk+$row1[1];}
                                            if (trim(strtoupper($row1[0]))=="BERKURANG")
                                            {$Keluar=$Keluar+$row1[1];}
                                         }
                                         $Total=$Masuk-$Keluar;
                                         ?>
                                           <input readonly size='45' type='text' value='<?php echo $row['nama']; ?>'STYLE="color: black; font-family: Verdana; font-weight: bold; font-size: 16px; background-color: #FF80FF;">
<br><br>
<div id="graph">Loading...</div>
<script type="text/javascript">
	var myData = new Array(['Masuk', <?php echo $Masuk; ?>], ['Keluar', <?php echo $Keluar; ?>], ['Total', <?php echo $Total; ?>]);
	var colors = ['#00FF00', '#EC7A00', '#008000'];
	var myChart = new JSChart('graph', 'bar');
	myChart.setDataArray(myData);
	myChart.colorizeBars(colors);
	myChart.setTitle('Kartu Aset <?php echo $namaBarang; ?>');
	myChart.setTitleColor('#8E8E8E');
	myChart.setAxisNameX('');
	myChart.setAxisNameY('');
	myChart.setAxisColor('#C4C4C4');
	myChart.setAxisNameFontSize(16);
	myChart.setAxisNameColor('#999');
	myChart.setAxisValuesColor('#7E7E7E');
	myChart.setBarValuesColor('#7E7E7E');
	myChart.setAxisPaddingTop(60);
	myChart.setAxisPaddingRight(140);
	myChart.setAxisPaddingLeft(150);
	myChart.setAxisPaddingBottom(40);
	myChart.setTextPaddingLeft(105);
	myChart.setTitleFontSize(11);
	myChart.setBarBorderWidth(1);
	myChart.setBarBorderColor('#C4C4C4');
	myChart.setBarSpacingRatio(50);
	myChart.setGrid(true);
	myChart.setSize(600, 321);
	myChart.setBackgroundImage('chart_bg.jpg');

	myChart.setFlagRadius(5);
	myChart.setTooltip(['Masuk', 'Jml <?php echo $Masuk;?>', 1], callback);
	myChart.setTooltip(['Keluar', 'Jml <?php echo $Keluar;?>' ,1], callback);
	myChart.setTooltip(['Total', 'Jml <?php echo $Total;?>', 1], callback);
	myChart.draw();

	function callback() {
		window.location = "mAsetLihatKabupaten.php?kodekabupaten=<?php echo $kodekabupaten; ?>&kodebarang=<?php echo $row['kodebarang']; ?>";
	}

</script>

                                           <?php
                                       }
                                       $pagination->pagination();
                                       //echo $total;

                                    }


?>
</font>
<br><br><br><br><br><br>

							</p>
						</div>
					</div>

					<div class="post">
					  <h1 class="title"><a href="#"><?php echo "User : (" . $_SESSION["userid"] . ")" . $_SESSION["nama"]; ?></a></h1>
					</div>

				</div>
				<!-- end #content -->
				<?php
                                include 'menuMasuk.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
