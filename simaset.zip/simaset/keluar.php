<?php
session_start();
$_SESSION['userid'] = "";
$_SESSION['nama'] = "";
header( 'Location: index.html' );
?>

