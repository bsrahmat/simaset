<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: keluar.php' );
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript">

var formInUse = false;

function setFocus()
{
 if(!formInUse) {
  document.input1.userid1.focus();
 }
}

</script>
</head>
<body  onload="setFocus()">
<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatasMasuk.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">
						<h1 class="title"><a href="#">Tambah Pengadaan</a></h1>
						<div class="entry">
						        </p>
						        <font size="3" face="arial" color="black">

   				    <?php
		                    include 'bukaDatabase.php';
		                    //Postgres = pg_escape_string()
                                    // generate and execute a query
                                    $kodebarang=trim(anti_injection($_POST['kodebarang']));
                                    $jumlah=trim(anti_injection($_POST['jumlah']));
                                    $hargasatuan=trim(anti_injection($_POST['hargaasli']));
                                    $kodekabupaten=trim(anti_injection($_POST['kodekabupaten']));
                                    $keterangan=trim(anti_injection($_POST['keterangan']));
                                    $date1=trim(anti_injection($_POST['date1']));
                                    if ($date1=="")
                                    {$date1 = date("Y-m-d");}
                                    if ($jumlah=="")
                                    {$jumlah = 0;}
                                    if ($hargasatuan=="")
                                    {$hargasatuan = 0;}

                                    $id2=0;


                                    $query = "select * from settingaset";
                                    $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
                                    $row = pg_num_rows($result);
                                    while ($row = pg_fetch_row($result))
                                    {
                                      $id2=$row[1] + 1;
                                      $query = "update settingaset set noinventaris=$id2";
                                      pg_query($connection, $query);
                                    }


                                    $query = "insert into aset(kodebarang,jumlah,harga,status,tanggal,userid,keterangan,kodekabupaten,id2,tglentry) values ";
                                    $query = $query . " ('$kodebarang',$jumlah,$hargasatuan,'bertambah','$date1','" . $_SESSION["userid"] ."','$keterangan','$kodekabupaten',$id2,now())";
                                    pg_query($connection, $query);

                                    header( "Location: mAsetLihat.php?kodebarang=$kodebarang");
                                     ?>
                                                </div>
                                           </div>
				</div>
				<!-- end #content -->
				<?php
                                include 'menuMasuk.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
