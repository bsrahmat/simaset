<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: keluar.php' );
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />



</head>
<body >



<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatasMasuk.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">
						<h1 class="title"><a href="#">Cari Aset</a></h1>
						<div class="entry">
						        </p>
<!-- tempat main tampilan -->


<form action="mAsetKartu2.php" method="get" name="input1">
<font size="3" face="arial" color="blue">Kabupaten<br><select name="kodekabupaten" STYLE="color: black; background-color: #80FF80;text-align: left">
<?php
  include 'bukaDatabase.php';
  $query = "select * from kabupaten order by kode";

  $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
  // get the number of rows in the resultset
  $rows = pg_num_rows($result);
  if ($rows != 0)
  {
    //echo "<table width='100%' border='1'>";
    while ($row = pg_fetch_row($result))
    {
      echo "<option value='" . $row[0] ."'>" . $row[1] . "</option>";
    }
  }
?>
</select>
<input type='hidden' name='Recordpage' value='1' size='3' maxlength='3'>
<input type='hidden' name='page' value='1'>
<br><br><input type='submit' name='masuk' value=' Kartu Pengawas Aset ' STYLE="color: white; font-family: Verdana; font-weight: bold; font-size: 18px; background-color: green;">
</form>

<br><br><br>
</font>
<br><br>
<br><br><br><br><br><br>

							</p>
						</div>
					</div>

					<div class="post">
					  <h1 class="title"><a href="#"><?php echo "User : (" . $_SESSION["userid"] . ")" . $_SESSION["nama"]; ?></a></h1>
					</div>

				</div>
				<!-- end #content -->
				<?php
                                include 'menuMasuk.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
