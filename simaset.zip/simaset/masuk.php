<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript">

var formInUse = false;

function setFocus()
{
 if(!formInUse) {
  document.input1.userid1.focus();
 }
}

</script>
</head>
<body  onload="setFocus()">
<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatas.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">

						<h1 class="title"><a href="#">Login</a></h1>
						<font size="3" face="arial" color="black">
				<!-- Begin #content -->
                                <?php

                                 $key=substr($_SESSION['key'],0,5);
                                 $number = $_REQUEST['number'];
                                 if($number!=$key)
                                 {
                                    echo '<center><font face="Verdana, Arial, Helvetica, sans-serif" color="#FF0000">Captcha salah! Silah Login Ulang!</font></center>';}
                                 else
                                 {
		                    $_SESSION['key']="";
		                    include 'bukaDatabase.php';
		                    //Postgres = pg_escape_string()
                                    // generate and execute a query
                                    $query = "SELECT * FROM tuser where userid='" . anti_injection($_POST['userid1'] ). "'";

                                    $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
                                    // get the number of rows in the resultset
                                    $rows = pg_num_rows($result);
                                    if ($rows != 0)
                                    {
                                    while ($row = pg_fetch_row($result))
                                    {
                                       if (trim($row[2])==trim(anti_injection($_POST['pass'])))
                                       {
                                          echo "password betul";
                                          $_SESSION['userid'] = trim($row[0]);
                                          $_SESSION['nama'] = trim($row[1]);
                                          $_SESSION['kodekabupaten']="";
                                          header( 'Location: main.php' );
                                       } else
                                       {
                                          echo "npm/password/captcha errorr!!";
                                          $_SESSION['kodekabupaten']="";
                                          $_SESSION['userid'] = "";
                                          $_SESSION['nama'] = "";
                                       }
                                    }
                                 }
                                    // close database connection
                                    pg_close($connection);
                                  }
                                  ?>
					</div>
				</div>
				<!-- end #content -->
				<?php
                                include 'menu.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
