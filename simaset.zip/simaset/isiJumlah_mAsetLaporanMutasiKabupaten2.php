<?php
$ket="";
//keadaan per 1 jan 2011
$query1 = "select status,harga,sum(jumlah) as jml ";
$query1 = $query1 . " from aset ";
$query1 = $query1 . " where tanggal < '" . $hasil[2] . "' and kodebarang='" . $row['kodebarang'] . "' and kodekabupaten='" . $row['kodekabupaten'] . "' ";
$query1 = $query1 . " group by status,harga ";

$result1 = pg_query($connection, $query1) or die("Error in query: $query1. " . pg_last_error($connection));
$rows1 = pg_num_rows($result1);
$totJml=0;
$totHarga=0;
while ($row1 = pg_fetch_row($result1))
{
   if (trim(strtoupper($row1[0]))=="BERTAMBAH")
   {
     $totJml=$totJml+$row1[2];
     $totHarga=$totHarga+ ($row1[2] * $row1[1]);
   }
   if (trim(strtoupper($row1[0]))=="BERKURANG")
   {
     $totJml=$totJml-$row1[2];
     $totHarga=$totHarga- ($row1[2] * $row1[1]);
   }
}
echo "<td align='center'>$totJml $satuan</td>";
echo "<td align='right'>Rp. " . number_format ( $totHarga , 2 , ',' , '.' ). "</td>";

//mutasi perubahan
$query1 = "select status,harga,keterangan,sum(jumlah) as jml ";
$query1 = $query1 . " from aset ";
$query1 = $query1 . " where tanggal between '" . $hasil[0] . "' and '" . $hasil[1] . "'  and kodebarang='" . $row['kodebarang'] . "' and kodekabupaten='" . $row['kodekabupaten'] . "' ";
$query1 = $query1 . " group by status,harga,keterangan ";

$result1 = pg_query($connection, $query1) or die("Error in query: $query1. " . pg_last_error($connection));
$rows1 = pg_num_rows($result1);
$JmlBerkurang=0;
$HargaBerkurang=0;
$JmlBertambah=0;
$HargaBertambah=0;
$ket="&nbsp";
while ($row1 = pg_fetch_row($result1))
{
   if (trim(strtoupper($row1[0]))=="BERTAMBAH")
   {
     $JmlBertambah=$JmlBertambah+$row1[3];
     $HargaBertambah=$HargaBertambah+ ($row1[3] * $row1[1]);
   }
   if (trim(strtoupper($row1[0]))=="BERKURANG")
   {
     $JmlBerkurang=$JmlBerkurang+$row1[3];
     $HargaBerkurang=$HargaBerkurang+ ($row1[3] * $row1[1]);
     //cari keterangan berkurang kenapa
     $ket=$row1[2];
   }
}
echo "<td align='center'>$JmlBerkurang $satuan</td>";
echo "<td align='right'>Rp. " . number_format ( $HargaBerkurang , 2 , ',' , '.' ). "</td>";
echo "<td align='center'>$JmlBertambah $satuan</td>";
echo "<td align='right'>Rp. " . number_format ( $HargaBertambah , 2 , ',' , '.' ). "</td>";

//keadaan per 31 des 2010 ........ persis dari keadaan per 1 jan 2011
echo "<td align='center'>$totJml $satuan</td>";
echo "<td align='right'>Rp. " . number_format ( $totHarga , 2 , ',' , '.' ). "</td>";

                                           echo "<td align='center'>$ket</td>";
                                           echo "</tr>";
?>
