<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: keluar.php' );
  }
?>
<body >
<?php
// untuk paging awal.....................................................
define("IN_PAGI", true);
$home="mAsetLaporanMutasiJenis1.php";
require("class_pagination.php");
$page = intval($_GET['page']);
if(empty($page))
{$page = 1;}
// untuk paging awal.....................................................
?>


<!-- tempat main tampilan -->
<?php
  //echo $_POST['date1'] . "<br><br><br>";
  //$hasil = preg_split('/,/', $_GET['date1']); // hasil

  $Recordpage=$_GET['Recordpage'];
  $semester=$_GET['semester'];
  $tahun=$_GET['tahun'];
  $judul="";
  if ($semester=="1")
  {
    $hasil[0]= $tahun . "-01-01";
    $hasil[1]= $tahun . "-07-31";
    $hasil[2]= $tahun-1 . "-12-31";
    $judul="SEMESTER I T.A $tahun";
  }
  if ($semester=="2")
  {
    $hasil[0]= $tahun . "-08-01";
    $hasil[1]= $tahun . "-12-31";
    $hasil[2]= $tahun . "-07-31";
    $judul="SEMESTER II T.A $tahun";
  }

  //echo "Awal : " . $hasil[0] . "<br><br><br>";
  //echo "Akhir : " . $hasil[1] . "<br><br><br>";
  //print_r($hasil);
?>
				<?php
		                    include 'bukaDatabase.php';

		                    //                         0     1        2           3
		                    $query = "select b.kodeklasifikasi,a.kodebarang,b.satuan,date_part('year',tanggal) as tahun,count(*) as jml from aset a, masterbarang b ";
                                    //$query = $query . " where a.tanggal between '" . $hasil[0] . "' and '" . $hasil[1] . "' and a.kodekabupaten=b.kode ";
                                    //-----------------------------------------------------jika menggunakan tanggal
                                    $query = $query . " where  a.kodebarang=b.kode ";
                                    $query = $query . " group by b.kodeklasifikasi,a.kodebarang,b.satuan,date_part('year',tanggal) ";
                                    $query = $query . " order by b.kodeklasifikasi,a.kodebarang,b.satuan,date_part('year',tanggal) ";

                                    $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
                                    $rows = pg_num_rows($result);
                                    $generated=$rows;

                                    //untuk paging
                                    //http://localhost/papua/mPengadaanLaporan2.php?date1=2011-10-1%2C2011-12-31&kodekomponen=0001&page=1&masuk=+Proses+Laporan+
		                    $pagination = new Pagination($Recordpage, $generated, $page, "mAsetLaporanMutasiJenis2.php?Recordpage=" . $Recordpage . "&tahun=". $_GET["tahun"] ."&semester=" . $_GET['semester'] . "&page");
                      		    $start = $pagination->prePagination();

                                    if ($rows != 0)
                                    {
                                       if ($page==1)
                                       {
                                         echo "<div align='center'><h2>REKAPITULASI MUTASI BARANG INVENTARIS<br>";
                                         echo "MILIK PROVINSI PAPUA<br>$judul</u></h2></div>";
                                       }
                                       echo "<table>";
                                       echo "<tr><td>SATUAN KERJA</td><td>: BADAN PENGELOLAAN INFRASTRUKTUR PROVINSI PAPUA</td></tr>";
                                       echo "</table>";
                                       echo "<table width='100%' border='1'>";

                                       //baris pertama
                                       echo "<tr bgcolor='#80FF80' align='center'>";
                                       echo "<td rowspan='3'>No</td>";
                                       echo "<td rowspan='3'>Kode Barang</td>";
                                       echo "<td rowspan='3' colspan='2'>Nama Barang</td>";

                                       $aBulan = array(1=>'Januari','Februari','Maret', 'April', 'Mei', 'Juni','Juli','Agustus','September','Oktober', 'November','Desember');
                                       $bulanSatu = date("d", strtotime($hasil[0])) . " ". $aBulan[(int)date("m", strtotime($hasil[0]))] . " " . date("Y", strtotime($hasil[0])) ;
                                       $bulanDua = date("d", strtotime($hasil[1])) . " ". $aBulan[(int)date("m", strtotime($hasil[1]))] . " " . date("Y", strtotime($hasil[1])) ;
                                       $bulanTiga = date("d", strtotime($hasil[2])) . " ". $aBulan[(int)date("m", strtotime($hasil[2]))] . " " . date("Y", strtotime($hasil[2])) ;

                                       echo "<td rowspan='2' colspan='2'>Keadaan Per " . $bulanSatu . "</td>";
                                       echo "<td colspan='4'>Mutasi Perubahan $bulanSatu s/d $bulanDua</td>";
                                       echo "<td rowspan='2' colspan='2'>Keadaan per $bulanTiga</td>";
                                       echo "<td rowspan='3'>Ket</td>";
                                       echo "</tr>";
                                       //baris kedua
                                       echo "<tr bgcolor='#80FF80' align='center'>";
                                       echo "<td colspan='2'>Berkurang</td>";
                                       echo "<td colspan='2'>Bertambah</td>";
                                       echo "</tr>";

                                       //baris ke tiga
                                       echo "<tr bgcolor='#80FF80' align='center'>";
                                       //keadaan per 1 jan 2011
                                       echo "<td >Jumlah</td>";
                                       echo "<td >Harga Ribuan</td>";
                                       //mutasi perubahan
                                       echo "<td >Jumlah</td>";
                                       echo "<td >Harga Ribuan</td>";
                                       echo "<td >Jumlah</td>";
                                       echo "<td >Harga Ribuan</td>";
                                       //Keadaan per 31 des 2011
                                       echo "<td >Jumlah</td>";
                                       echo "<td >Harga Ribuan</td>";
                                       echo "</tr>";

                                       //baris 1,2,3,4....
                                       echo "<tr bgcolor='#80FF80'>";
                                       echo "<td align='center'>1</td><td align='center'>2</td><td align='center' colspan='2'>3</td><td align='center'>4</td><td align='center'>5</td><td align='center'>6</td><td align='center'>7</td><td align='center'>8</td><td align='center'>9</td><td align='center'>10</td><td align='center'>11</td><td align='center'>12</td>";
                                       echo "</tr>";

                                       $vNo=0;

                                       //untuk paging
		                       $query = "select b.kodeklasifikasi,a.kodebarang,b.satuan,date_part('year',tanggal) as tahun,count(*) as jml from aset a, masterbarang b ";
                                       //$query = $query . " where a.tanggal between '" . $hasil[0] . "' and '" . $hasil[1] . "' and a.kodekabupaten=b.kode ";
                                       //-----------------------------------------------------jika menggunakan tanggal
                                       $query = $query . " where  a.kodebarang=b.kode ";
                                       $query = $query . " group by b.kodeklasifikasi,a.kodebarang,b.satuan,date_part('year',tanggal) ";
                                       $query = $query . " order by b.kodeklasifikasi,a.kodebarang,b.satuan,date_part('year',tanggal) LIMIT $Recordpage OFFSET $start ";

                                       $query2  = pg_query($query);

                                       $vKode="";
                                       $namabarang="";
                                       while($row = pg_fetch_assoc($query2))
                                       //while ($row = pg_fetch_row($query))
                                       {
                                         $vNo = $vNo + 1;
                                         $satuan=trim($row['satuan']);
                                         echo $satuan;
                                         if ($vKode <> $row['kodeklasifikasi'])
                                         {
                                           //cari jml colspan kode dan no .................
                                           $query1 = "select a.kodeklasifikasi,count(*) as jml from ";
                                           $query1 = $query1 . " ( ";
                                           $query1 = $query1 . " select b.kodeklasifikasi,a.kodebarang,date_part('year',tanggal) as tahun,count(*) as jml from aset a, masterbarang b ";
                                           //$query1 = $query1 . " where a.tanggal between '" . $hasil[0] . "' and '" . $hasil[1] . "' and a.kodekabupaten=b.kode ";
                                           //-----------------------------------------------------jika menggunakan tanggal
                                           $query1 = $query1 . " where  a.kodebarang=b.kode ";
                                           $query1 = $query1 . " group by b.kodeklasifikasi,a.kodebarang,date_part('year',tanggal) ";
                                           $query1 = $query1 . " order by b.kodeklasifikasi,a.kodebarang,date_part('year',tanggal) ";
                                           $query1 = $query1 . " ) a ";
                                           $query1 = $query1 . " where a.kodeklasifikasi='" . $row['kodeklasifikasi'] . "' ";
                                           $query1 = $query1 . " group by a.kodeklasifikasi ";

                                           $jmlCol=0;
                                           $result1 = pg_query($connection, $query1) or die("Error in query: $query1. " . pg_last_error($connection));
                                           $rows1 = pg_num_rows($result1);
                                           while ($row1 = pg_fetch_row($result1))
                                           {
                                             $jmlCol=$row1[1]+1;
                                           }
                                           //cari jml colspan kode dan no end..................

                                           //nama klasifikasi
                                           $namaklasifikasi="";
                                           $query1 = "select * from klasifikasi where kode='" . $row['kodeklasifikasi'] . "'";
                                           $result1 = pg_query($connection, $query1) or die("Error in query: $query1. " . pg_last_error($connection));
                                           $rows1 = pg_num_rows($result1);
                                           while ($row1 = pg_fetch_row($result1))
                                           {
                                             $namaklasifikasi = trim($row1[1]);
                                           }

                                           ?><tr onMouseOver="this.bgColor='#FFFF80'" onMouseOut="this.bgColor='#EAFFEA'" bgcolor='#EAFFEA'><?php
                                           echo "<td rowspan='$jmlCol'>&nbsp</td><td rowspan='$jmlCol'>&nbsp</td>";
                                           echo "<td colspan='11'><b>" . trim(stripslashes(htmlspecialchars($row['kodeklasifikasi']))) . ". $namaklasifikasi </b></td>";
                                           $vKode=$row['kodeklasifikasi'];
                                           //echo "<td align='center'>&nbsp</td><td align='center'>&nbsp</td><td align='center'>&nbsp</td><td align='center'>&nbsp</td><td align='center'>&nbsp</td><td align='center'>&nbsp</td><td align='center'>&nbsp</td><td align='center'>&nbsp</td><td align='center'>&nbsp</td><td align='center'>&nbsp</td>";
                                           echo "</tr>";
                                           ?><tr onMouseOver="this.bgColor='#FFFF80'" onMouseOut="this.bgColor='#EAFFEA'" bgcolor='#EAFFEA'><?php
                                           //echo "<td></td><td></td>";
                                         } else
                                         {
                                           ?><tr onMouseOver="this.bgColor='#FFFF80'" onMouseOut="this.bgColor='#EAFFEA'" bgcolor='#EAFFEA'><?php
                                           //echo "<td></td><td></td>";
                                         }

                                           //cari jml colspan untuk nama barang
                                           $query1 = "select a.kodebarang,count(*) as jml from ";
                                           $query1 = $query1 . " ( ";
                                           $query1 = $query1 . " select b.kodeklasifikasi,a.kodebarang,date_part('year',tanggal) as tahun,count(*) as jml from aset a, masterbarang b ";
                                           //$query1 = $query1 . " where a.tanggal between '" . $hasil[0] . "' and '" . $hasil[1] . "' and a.kodekabupaten=b.kode ";
                                           //-----------------------------------------------------jika menggunakan tanggal
                                           $query1 = $query1 . " where  a.kodebarang=b.kode ";
                                           $query1 = $query1 . " group by b.kodeklasifikasi,a.kodebarang,date_part('year',tanggal) ";
                                           $query1 = $query1 . " order by b.kodeklasifikasi,a.kodebarang,date_part('year',tanggal) ";
                                           $query1 = $query1 . " ) a ";
                                           $query1 = $query1 . " where a.kodebarang='" . $row['kodebarang'] . "' ";
                                           $query1 = $query1 . " group by a.kodebarang ";

                                           $jmlCol2=0;
                                           $result1 = pg_query($connection, $query1) or die("Error in query: $query1. " . pg_last_error($connection));
                                           $rows1 = pg_num_rows($result1);
                                           while ($row1 = pg_fetch_row($result1))
                                           {
                                             $jmlCol2=$row1[1];
                                           }
                                           //cari jml colspan untuk nama barang end.................

                                         //nama barang
                                         $query1 = "select * from masterbarang where kode='" . $row['kodebarang'] . "'";
                                         $result1 = pg_query($connection, $query1) or die("Error in query: $query1. " . pg_last_error($connection));
                                         $rows1 = pg_num_rows($result1);
                                         while ($row1 = pg_fetch_row($result1))
                                         {
                                            if (trim($namabarang) <> trim($row1[1]))
                                            {
                                               $namabarang = trim($row1[1]);
                                               echo "<td rowspan='$jmlCol2'>" . trim($row1[1]) . "</td>";
                                            }
                                            echo "<td>" . $row['tahun'] . "</td>";
                                            include 'isiJumlah_mAsetLaporanMutasiJenis2.php';
                                         }


                                       }
                                       echo "</table>";
		                       $pagination->pagination();
                                    }
                                     ?>
                                     <?php
                                        if ($current_page == $total)
                                        {
                                     ?>
                                     <table width='100%' border='0'>
                                        <tr><td>
                                        <?php
                                        for ( $counter = 0; $counter <= 90; $counter += 1)
                                        {
                                          echo "&nbsp";
                                        }
                                        ?>
                                        </td>
                                        <td align='center'>
                                        KEPALA<br>
                                        BADAN PENGELOLAAN INFRASTRUKTUR<br>
                                        PROVINSI PAPUA<br>
                                        <br><br><br>
                                        Ir.J.I.CHRISTIANWAYOI,MMT,MT<br>
                                        Pembina Utama Muda<br>
                                        NIP.19590101 199103 1 013

                                        </td></tr>
                                     </table>
                                     <?php
                                        }
                                     ?>

</html>
