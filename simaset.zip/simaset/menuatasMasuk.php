<?php
  if ($_SESSION['userid']=="")
  {
     exit();
  }
?>
<div id="menu">
	<ul>
		<li class="first"><a href="main.php">Beranda</a></li>
		<li><a href="#">Manual</a></li>
		<li><a href="mKabupaten.php">Daftar Kabupaten</a></li>
		<li><a href="mKlasifikasi.php">Klasifikasi Barang</a></li>
		<li><a href="mKomponen.php">Komponen Barang</a></li>
		<li><a href="keluar.php">Keluar</a></li>
	</ul>
</div>

