<?php

	/*==================================================================*\
	######################################################################
	#                                                                    #
	# Copyright 2009 Dynno.net .  All Rights Reserved.                   #
	#                                                                    #
	# This file may not be redistributed in whole or part.               #
	# 							                                         #
	# Developed by: $ID: 1 $UNI: Imad Jomaa                              #
	# ----------------------- THIS FILE PREFORMS ----------------------- #
	#                                                                    #
	# Pagination Conditionals                                            #
	######################################################################
	\*==================================================================*/

//include the necessary language pack
require("assetsPAGE/language_pack.php");

global $previous, $next, $location, $total, $current_page,$home;

$page = $current_page;


echo "<div class=\"pagination\" align=\"right\">\n";

if($next < 1)
{
  $next =  "<span class=\"pagination_disabled\">$plang[1] &raquo;</span>";
}

if($next >= 1)
{
  $next = "<a href=\"$location=$next\" title=\"\">$plang[1] &raquo;</a>";
}

if($previous < 1)
{
  $previous =  "<span class=\"pagination_disabled\">&laquo; $plang[2]</span>";
}

if($previous >= 1)
{
  $previous = "<a href=\"$location=$previous\" title=\"\">&laquo; $plang[2]</a>";
}

echo "<a href='$home'><img width='18' src='images/home.jpg'></a> ";
echo $previous;
echo "Hal : $page";
/*
if($total <= 7)
{
  for($counter = 1; $counter <= $total; $counter++)
  {
    if($page == $counter)
    {
      echo "<span class=\"pagination_current\">$counter</span>";
    }

    else
    {
      echo "<a href=\"$location=$counter\" title=\"\">$counter</a>";  
    }
  }
}

elseif($total > 7 && $page <= 7)
{
  if($page + 3 == $total)
  {
    $cc = $page + 3;
    $extra = false;
  }

  elseif($page + 3 > $total)
  {
    $cc = $page;
    $extra = false;
  }
  
  else
  {
    $cc = $page + 3;
    $extra = true;
  }

  for($counter = 1; $counter <= $cc; $counter++)
  {
    if($page == $counter)
    {
      echo "<span class=\"pagination_current\">$counter</span>";
    }

    else
    {
      echo "<a href=\"$location=$counter\" title=\"\">$counter</a>";  
    }
  }
  
  if($extra == TRUE)
  {
    echo "...";
    echo "<a href=\"$location=$total\" title=\"\">$total</a>";  
  }
}


elseif($page > 7 && $page < $total - 3)
{

  echo "<a href=\"$location=1\" title=\"\">1</a>";  
  echo "...";

  for($counter = $page - 3; $counter <= $page + 3; $counter++)
  {
    if($page == $counter)
    {
      echo "<span class=\"pagination_current\">$counter</span>";
    }
  
    else
    {
      echo "<a href=\"$location=$counter\" title=\"\">$counter</a>";  
    }
  }

  echo "...";
  echo "<a href=\"$location=$total\" title=\"\">$total</a>";  

}

elseif($page > 7 && $page + 3 == $total)
{

  echo "<a href=\"$location=1\" title=\"\">1</a>";  
  echo "...";

  for ($counter = $page - 3; $counter <= $page + 3; $counter++)
  {

    if($counter == $page)
    {
      echo "<span class=\"pagination_current\">$counter</span>";
    }
    
    else
    {
      echo "<a href=\"$location=$counter\" title=\"\">$counter</a>";  
    }    
  }
} 

else
{

  echo "<a href=\"$location=1\" title=\"\">1</a>";  
  echo "...";

  for ($counter = $page - 3; $counter <= $total; $counter++)
  {

    if($counter == $page)
    {
      echo "<span class=\"pagination_current\">$counter</span>";
    }
    
    else
    {
      echo "<a href=\"$location=$counter\" title=\"\">$counter</a>";  
    }    
  }
} 
*/
echo "$next" ;

//time to get a jump-to list going

//let's display the select box

?>
<!--
<form name="jumping" class="form_pagination">
	<select name="jumpto" id="jumpto">
-->
	<?php
		//for($i=1; $i <= $total; $i++)
	//	{
    		//	echo "		<option value=\"$i\">$i</option>";
		//}

	//echo <<<HERE
	//</select>
	//<input type="button" name="go" value="$plang[3]" onClick="window.location=('$location='+document.jumping.jumpto.options[document.jumping.jumpto.selectedIndex].value)">
//</form>
//HERE;

echo "</div>\n";
?>
