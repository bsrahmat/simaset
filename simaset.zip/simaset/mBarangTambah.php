<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: keluar.php' );
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript">

var formInUse = false;

function setFocus()
{
 if(!formInUse) {
  document.input1.userid1.focus();
 }
}

</script>
</head>
<body  onload="setFocus()">
<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatasMasuk.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">
						<h1 class="title"><a href="#">Tambah Master Barang</a></h1>
						<div class="entry">
						        </p>
						        <font size="3" face="arial" color="black">
                                       <?php
   		                         include 'bukaDatabase.php';
                                         echo "<FORM action='mBarangTSimpan.php' method='post' name='input1'>";
                                         echo "Kode <br><input name='kode' size='10'type='text' STYLE='color: black; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #E1FFF0;'  ><br><br>";
                                         echo "Nama <br><input name='nama' size='50'type='text' STYLE='color: black; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #E1FFF0;'><br><br>";

                                         //untuk klasifikasi
                                         echo "Klasifikasi <br><select name='kodeklasifikasi' STYLE='color: black; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #E1FFF0;'>";
                                         $query = "SELECT * FROM klasifikasi order by kode";
                                         $result1 = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
                                         $rows1 = pg_num_rows($result1);
                                         echo "<option  value=''></option>";
                                         while ($row1 = pg_fetch_row($result1))
                                         {
                                                echo "<option value='$row1[0]'>$row1[1]</option>";
                                         }
                                         echo "</select><br><br>";

                                         //untuk komponen
                                         echo "Komponen <br><select name='kodekomponen' STYLE='color: black; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #E1FFF0;'>";
                                         $query = "SELECT * FROM komponen order by kode";
                                         $result1 = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
                                         $rows1 = pg_num_rows($result1);
                                         echo "<option  value=''></option>";
                                         while ($row1 = pg_fetch_row($result1))
                                         {
                                                echo "<option value='$row1[0]'>$row1[1]</option>";
                                         }
                                         echo "</select><br><br>";

                                         //untuk Status
                                         //echo "Status <br><select name='status' STYLE='color: black; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #E1FFF0;'><br>";
                                         //  echo "<option value='1'>Bisa Masuk Ke Aset</option>";
                                         //  echo "<option  value='0'>Tidak Bisa Ke Aset</option>";
                                         //echo "</select><br><br>";
                                         
                                         echo "Satuan <br><input name='satuan' size='10' maxlength='10' type='text' STYLE='color: black; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: #E1FFF0;'><br><br>";

                                         echo "<input type='submit' value='Simpan' STYLE='color: black; font-family: Verdana; font-weight: bold; font-size: 16px; background-color: #00FF40;'>";
                                         echo "</FORM><br><br><br>";

                                       //echo "</table>";

                                     ?>
                                     </font>
							</p>
						</div>
					</div>

					<div class="post">
					  <h1 class="title"><a href='mBarang.php'><img width='70'src='images/back.jpg'></a> </h1><br><br><br><br><br>
					  <h1 class="title"><a href="#"><?php echo "User : (" . $_SESSION["userid"] . ")" . $_SESSION["nama"]; ?></a></h1>
					</div>

				</div>
				<!-- end #content -->
				<?php
                                include 'menuMasuk.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
