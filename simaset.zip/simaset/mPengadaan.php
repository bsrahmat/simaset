<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: keluar.php' );
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript">

var formInUse = false;

function setFocus()
{
 if(!formInUse) {
  document.input1.userid1.focus();
 }
}

</script>

<script type="text/javascript">
<!-- Begin ....................... script untuk rupiah .....................
function formatCurrency(num) {
document.input1.hargaasli.value = num;
num = num.toString().replace(/\Rp. |\,/g,'');
if(isNaN(num))
num = "0";
sign = (num == (num = Math.abs(num)));
num = Math.floor(num*100+0.50000000001);
cents = num%100;
num = Math.floor(num/100).toString();
if(cents<10)
cents = "0" + cents;
for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
num = num.substring(0,num.length-(4*i+3))+','+
num.substring(num.length-(4*i+3));
return (((sign)?'':'-') + 'Rp. ' + num + '.' + cents);
}
//  End -->
</script>


</head>
<body  onload="setFocus()">



<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatasMasuk.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">
						<h1 class="title"><a href="#">Input Pengadaan</a></h1>
						<div class="entry">
						        </p>
<!-- tempat main tampilan -->
<div align='right'>
<img src='images/tambah.jpg'>
</div>
<form action="mPengadaanSimpan.php" method="post" name="input1">
<font size="3" face="arial" color="blue">No Kontrak<br><input size='20' maxlength='20' type="text" name="no"><br><br>
Nama Barang<br><select name="kodebarang">
<?php
  include 'bukaDatabase.php';
  //Postgres = pg_escape_string()
  // generate and execute a query
  $query = "SELECT * FROM masterbarang order by kode";

  $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
  // get the number of rows in the resultset
  $rows = pg_num_rows($result);
  if ($rows != 0)
  {
    //echo "<table width='100%' border='1'>";
    while ($row = pg_fetch_row($result))
    {
      echo "<option value='" . $row[0] ."'>" . $row[1] . "</option>";
    }
  }
?>
</select><br><br>
<table>
<tr><td>
Jumlah<br><input type="text" size='5' maxlength='3' name="jumlah"  style="text-align: right" >
</td><td>
Harga Satuan<br><input type="text" name="hargasatuan"  style="text-align: right" onBlur="this.value=formatCurrency(this.value);">
<input type="hidden" name="hargaasli">
</td>
</table>
<br>
Pemeriksaan Barang<br><input size='20' maxlength='20' type="text" name="pemeriksaan"><br><br>
Rekanan<br><select name="koderekanan">
<?php
  //Postgres = pg_escape_string()
  // generate and execute a query
  $query = "SELECT * FROM rekanan order by kode";

  $result = pg_query($connection, $query) or die("Error in query: $query. " . pg_last_error($connection));
  // get the number of rows in the resultset
  $rows = pg_num_rows($result);
  echo "<option value=''></option>";
  if ($rows != 0)
  {
    //echo "<table width='100%' border='1'>";
    while ($row = pg_fetch_row($result))
    {
      echo "<option value='" . $row[0] ."'>" . $row[1] . "</option>";
    }
  }

?>
</select><br><br>
<table border='0'>
<tr><td>
Keterangan<br><input size='20' maxlength='20' type="text" name="keterangan"><br><br>
</td><td valign='top'>
<!-- .......................................................... untuk memasukan  tanggal -->
Tanggal<br><input type="text" id="date1" name="date1" />
<script type="text/javascript">
    var ng_config = {
        assests_dir: 'assets/'	// the path to the assets directory
    }
</script>
<script type="text/javascript" src="ng_all.js"></script>
<script type="text/javascript" src="components/calendar.js"></script>
<script type="text/javascript">
var my_cal;
ng.ready(function(){
        // creating the calendar
        my_cal = new ng.Calendar({
            input: 'date1',            // the input field id
            start_date: 'year - 5',    // the start date (default is today)
            display_date: new Date()   // the display date (default is start_date)
        });
    });
</script>
</td></tr></table>

<input type="submit" value=" SIMPAN " STYLE="color: white; font-family: Verdana; font-weight: bold; font-size: 18px; background-color: green;">
</form>
</font>
<br><br><br><br><br><br>

							</p>
						</div>
					</div>

					<div class="post">
					  <h1 class="title"><a href="#"><?php echo "User : (" . $_SESSION["userid"] . ")" . $_SESSION["nama"]; ?></a></h1>
					</div>

				</div>
				<!-- end #content -->
				<?php
                                include 'menuMasuk.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
