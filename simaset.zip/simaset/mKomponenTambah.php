<?php
session_start();
?>
<?php
include 'sqlInjection.php'
?>
<?php
  if ($_SESSION['userid']=="")
  {
     header( 'Location: index.html' );
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Manajemen Aset</title>
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript">

var formInUse = false;

function setFocus()
{
 if(!formInUse) {
  document.input1.userid1.focus();
 }
}

</script>
</head>
<body  onload="setFocus()">
<div id="header">
	<div id="logo">
		<h1><a href="#"></a></h1>
	</div>
</div>
<!-- end #header -->
<?php
include 'menuatasMasuk.php'
?>
<!-- end #menu -->
<div id="wrapper">
	<div id="wrapper-top">
		<div id="wrapper-btm">
			<div id="page">
				<div id="content">
					<div class="post">
						<h1 class="title"><a href="#">Tambah Komponen Barang</a></h1>
						<div class="entry">
						        </p>
						        <font size="3" face="arial" color="black">
				<?php
                                       echo "<table width='100%' border='0'>";
                                         echo "<FORM action='mKomponenTSimpan.php' method='post' name='input1'>";
                                         echo "<tr><td align='right'>Kode : </td><td><input name='kode' maxlength='4' size='4'type='text'  ></td></tr>";
                                         echo "<tr><td align='right'>Nama Komponen Barang : </td><td><input name='nama' maxlength='100' size='50'type='text'  STYLE='color: black; font-family: Verdana; font-weight: bold; font-size: 12px; background-color: white;'></td></tr>";
                                         echo "<tr><td align='right'></td><td><input type='submit' value='Simpan' STYLE='color: white; font-family: Verdana; font-weight: bold; font-size: 16px; background-color: blue;'></td></tr>";
                                         echo "</FORM>";
                                       echo "</table>";
                                     ?>
                                     </font>
							</p>
						</div>
					</div>

					<div class="post">
					  <h1 class="title"><a href="#"><?php echo "User : (" . $_SESSION["userid"] . ")" . $_SESSION["nama"]; ?></a></h1>
					</div>

				</div>
				<!-- end #content -->
				<?php
                                include 'menuMasuk.php'
                                ?>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #page -->
		</div>
	</div>
</div>
<div id="footer">
	<p>Copyright (c) 2012 Propinsi Papua</p>
</div>
<!-- end #footer
<div style="text-align: center; font-size: 0.75em;">Design downloaded from <a href="http://www.freewebtemplates.com/">free website templates</a>.</div></body>
-->
</html>
