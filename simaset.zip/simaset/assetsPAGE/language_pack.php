<?php

	/*==================================================================*\
	######################################################################
	#                                                                    #
	# Copyright 2009 Dynno.net .  All Rights Reserved.                   #
	#                                                                    #
	# This file may not be redistributed in whole or part.               #
	# 							                                         #
	# Developed by: $ID: 1 $UNI: Imad Jomaa                              #
	# ----------------------- THIS FILE PREFORMS ----------------------- #
	#                                                                    #
	# Pagination Language File                                           #
	######################################################################
	\*==================================================================*/
   
   //$plang[1] = "<img width='15' src='assetsPAGE/next.gif'>";
   //$plang[2] = "<img width='15' src='assetsPAGE/prev.gif'>";
   //$plang[3] = "Go!";

   $plang[1] = "";
   $plang[2] = "";
   $plang[3] = "";
?>
