/*
 * NoGray JavaScript Library v1.0
 * http://www.NoGray.com
 *
 * Copyright (c) 2009 Wesam Saif
 * http://www.nogray.com/license.php
 */

ng.Language.set_language('ar', {
	// calendar component
	view_selected_dates:'عرض التواريخ المختارة',
	hide_selected_dates:'إخفاء التواريخ المختارة'
});
