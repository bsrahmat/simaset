<?php
$ket="";
//keadaan per 1 jan 2011
$query1 = "select a.status,a.harga,b.satuan,sum(a.jumlah) as jml ";
$query1 = $query1 . " from aset a, masterbarang b ";
$query1 = $query1 . " where date_part('year',a.tanggal)=" . $row['tahun'] . " and a.kodebarang=b.kode and a.tanggal < '" . $hasil[2] . "' and a.kodebarang='" . $row['kodebarang'] . "' and b.kodeklasifikasi='" . trim($row['kodeklasifikasi']) . "' ";
$query1 = $query1 . " group by a.status,a.harga,b.satuan ";

$result1 = pg_query($connection, $query1) or die("Error in query: $query1. " . pg_last_error($connection));
$rows1 = pg_num_rows($result1);
$totJml=0;
$totHarga=0;
//$satuan="";
while ($row1 = pg_fetch_row($result1))
{
   //$satuan=$row1[2];
   if (trim(strtoupper($row1[0]))=="BERTAMBAH")
   {
     $totJml=$totJml+$row1[3];
     $totHarga=$totHarga+ ($row1[3] * $row1[1]);
   }
   if (trim(strtoupper($row1[0]))=="BERKURANG")
   {
     $totJml=$totJml-$row1[3];
     $totHarga=$totHarga- ($row1[3] * $row1[1]);
   }
}
echo "<td align='center'>$totJml " . trim($satuan) . "</td>";
echo "<td align='right'>Rp. " . number_format ( $totHarga , 2 , ',' , '.' ). "</td>";

//mutasi perubahan
$query1 = "select a.status,a.harga,a.keterangan,b.satuan,sum(a.jumlah) as jml ";
$query1 = $query1 . " from aset a, masterbarang b ";
$query1 = $query1 . " where date_part('year',a.tanggal)=" . $row['tahun'] . " and a.kodebarang=b.kode and a.tanggal between '" . $hasil[0] . "' and '" . $hasil[1] . "'  and a.kodebarang='" . $row['kodebarang'] . "' and b.kodeklasifikasi='" . trim($row['kodeklasifikasi']) . "' ";
$query1 = $query1 . " group by a.status,a.harga,a.keterangan,b.satuan ";
$result1 = pg_query($connection, $query1) or die("Error in query: $query1. " . pg_last_error($connection));
$rows1 = pg_num_rows($result1);
$JmlBerkurang=0;
$HargaBerkurang=0;
$JmlBertambah=0;
$HargaBertambah=0;
$ket="&nbsp";
$sat2="";
while ($row1 = pg_fetch_row($result1))
{
   //$sat2=$row1[3];
   if (trim(strtoupper($row1[0]))=="BERTAMBAH")
   {
     $JmlBertambah=$JmlBertambah+$row1[4];
     $HargaBertambah=$HargaBertambah+ ($row1[4] * $row1[1]);
   }
   if (trim(strtoupper($row1[0]))=="BERKURANG")
   {
     $JmlBerkurang=$JmlBerkurang+$row1[4];
     $HargaBerkurang=$HargaBerkurang+ ($row1[4] * $row1[1]);
     //cari keterangan berkurang kenapa
     $ket=$row1[2];
   }
}
echo "<td align='center'>$JmlBerkurang " . trim($satuan) . "</td>";
echo "<td align='right'>Rp. " . number_format ( $HargaBerkurang , 2 , ',' , '.' ). "</td>";
echo "<td align='center'>$JmlBertambah " . trim($satuan) . "</td>";
echo "<td align='right'>Rp. " . number_format ( $HargaBertambah , 2 , ',' , '.' ). "</td>";

//keadaan per 31 des 2010 ........ persis dari keadaan per 1 jan 2011
echo "<td align='center'>$totJml $satuan</td>";
echo "<td align='right'>Rp. " . number_format ( $totHarga , 2 , ',' , '.' ). "</td>";

                                           echo "<td align='center'>$ket</td>";
                                           echo "</tr>";
?>
